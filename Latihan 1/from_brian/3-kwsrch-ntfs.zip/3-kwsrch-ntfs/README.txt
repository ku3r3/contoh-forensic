
                      Test 3 - NTFS Keyword Search Image #1
                                   October 2003


                                   Brian Carrier

---------------------------------------------------------------------------
This is a test image for testing digital forensic analysis tools.
Import it into the tool of your choice (it is an NTFS file system
image in a raw format) and search for the terms identified in the
'index.html' file.

This image is released under the terms of the GNU General Public
License as published by the Free Software Foundation.  It is included
in the COPYING file.

